import './App.css';
import SearchImageApp from './components/search';

function App() {
  return (
    <div className="App">
      <SearchImageApp/>
    </div>
  );
}

export default App;
